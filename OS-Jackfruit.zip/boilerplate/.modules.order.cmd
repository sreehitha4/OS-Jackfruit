savedcmd_/home/sreehitha/OS-Jackfruit/boilerplate/modules.order := {   echo /home/sreehitha/OS-Jackfruit/boilerplate/monitor.o; :; } > /home/sreehitha/OS-Jackfruit/boilerplate/modules.order
